b = 78778
print(b)