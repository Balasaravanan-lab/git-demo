#!/bin/bash
#!/usr/bin/env python



sudo python3 app_stop.py >> output.txt