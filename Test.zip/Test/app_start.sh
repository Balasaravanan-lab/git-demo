#!/bin/bash
#!/usr/bin/env python

sudo python3 /tmp/python_scripts/app_start.py >> output.txt